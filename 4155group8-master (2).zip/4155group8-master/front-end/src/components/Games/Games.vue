<template>
  <div class="text-center games">
    <h1 >Conversate</h1>
    <h2>Welcome to the games page. </h2>
    <p class="lead">
      We playin games here.

    </p>
  </div>
</template>

<script>
export default {
  name: "Games"
};
</script>
