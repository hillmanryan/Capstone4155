from .translate_bp import translate_bp
