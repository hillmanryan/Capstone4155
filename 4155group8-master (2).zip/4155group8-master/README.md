#Steps to setting up both frontend and backend and contributing

 - make a new folder on your machine, in a powershell/terminal  - window navigate to the folder.

Once navigated to the folder in terminal, initialize an empty git repository and add origin as a remote with https

```git init```
```git remote add origin https://cci-git.uncc.edu/omartin8/4155group8.git```
```git pull origin master```











After changes are made to files:
 - Save all files
 - Execute ```git pull origin master``` to ensure that your working branch is up to date with the master branch.  
 - Fix merge conflicts if necessary, the best way I've found to do it is pycharm
 - Add all your changes to your git branch with ```git add .```
 - Push all your changes to your branch on git with ```git push {}```



